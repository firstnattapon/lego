# Copyright 2022 Webull
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# 	http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# coding=utf-8

from webull.core.request import ApiRequest


class GetInstrumentsRequestV2(ApiRequest):
    def __init__(self):
        ApiRequest.__init__(self, "/trading/instruments/stocks/profiles/list", version='v3', method="GET",
                            query_params={})

    def set_symbols(self, symbols):
        if isinstance(symbols, str):
            self.add_query_param("symbols", symbols)
        elif isinstance(symbols, list):
            self.add_query_param("symbols", ",".join(symbols))

    def set_category(self, category):
        self.add_query_param("category", category)

    def set_status(self, status):
        if status:
            self.add_query_param("status", status)

    def set_sub_category(self, sub_category):
        if sub_category:
            self.add_query_param("sub_category", sub_category)

    def set_pagination_key(self, pagination_key):
        if pagination_key:
            self.add_query_param("pagination_key", pagination_key)
