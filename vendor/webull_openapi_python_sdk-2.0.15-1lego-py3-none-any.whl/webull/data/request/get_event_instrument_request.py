# Copyright 2022 Webull
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# 	http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# coding=utf-8

from webull.core.request import ApiRequest

class GetEventInstrumentRequest(ApiRequest):
    def __init__(self):
        ApiRequest.__init__(self, "/openapi/instrument/event/market/list", version='v2', method="GET", query_params={})

    def set_series_symbol(self, series_symbol):
        self.add_query_param("series_symbol", series_symbol)

    def set_event_symbol(self, event_symbol):
        self.add_query_param("event_symbol", event_symbol)

    def set_symbols(self, symbols):
        if isinstance(symbols, str):
            self.add_query_param("symbols", symbols)
        elif isinstance(symbols, list):
            self.add_query_param("symbols", ",".join(symbols))

    def set_expiration_date_after(self, expiration_date_after):
        self.add_query_param("expiration_date_after", expiration_date_after)

    def set_last_instrument_id(self, last_instrument_id):
        self.add_query_param("last_instrument_id", last_instrument_id)

    def set_page_size(self, page_size):
        self.add_query_param("page_size", page_size)